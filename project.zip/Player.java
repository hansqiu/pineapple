 /** 
 * player A and player B will join the game
 * @author Team Pineapple
 *
 */
public enum Player{
    A, B
}