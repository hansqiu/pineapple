/**
 * A concrete class implementing galaxy theme for GameStyle interface 
 * @author Team Pineapple
 * CS 151 Spring 2018
 */

public class GalaxyStyle implements GameStyle 
{
	/**
	 * To return a path of a stone image for Galaxy Theme
	 */
	public String getStonePic() {
		return "image/GalaxyStone.png";
	}

	/**
	 * To return a path of a pit image for Galaxy Theme
	 */
	public String getPitPic() 
	{
		return "image/GalaxyPit.png";
	}

	/**
	 * To return a path of a mancala image for Galaxy Theme
	 */
	public String getMancalaPic(Player p) 
	{
		return "image/GalaxyMancala.png";
	}

}